# Monumenta Resource Pack Contributors (including those who contributed to the original pack):

## Current Artists
* Xernial (xernial)
* Woohard (woohard)
* OurStoRi / Icyl0t (ourstori)
* mscr (mscr.)
* Pacific (pacific_legend)
* Grape (agrxpe)
* GardeniaBud (metazoa.0386)
* Diec (diec_)
* memelord1625 (memelord1625)
* panne (pyjyamas)
* Shushi_794 (Zsushi#5135)
* VoidBlast (mgviral)
* Day (capriisona)

## Past Artists and those who contributed in others way
* U5B and Vladomeme (usb, vladomeme) * (For making the pack work better with OptiFine alternatives)
* needmoney90 * (For making tools to speed up pack development)
* Spy21DD (spy1dd) * (For writing the how-to guide)
* Aristotle (c.s.aristotle) * (For early contributions and handling Hope Skin requests)
* fron (fron#0019)
* Nolvid (Nolvid#6144)
* Rhino (rhinowo_)
* Skyzor (skyzory)
* SuzunaAoi (suzunaaoi)
* Cobalts (cobalts)
* BobbyJonesSr (bobbyjonessr)
* Deneb (astraldaughter)
* Jackie (anomalockaris)
* Xeronsis (xeronsis)
* zwrboo (zwrboo)
* rayman520 (rayman520)
* NickNackGus (nicknackgus)
* Noelle (kindabland)
* Data (datacrusader)
* Randy (oldstories)
* Kiocifer (kiocifer)
* Papaya (Papaya#1254)
* Smolegit (smolegit)
* Abyssfir3 (HardShell#7131)
* ProbsWinter (Winter#9769)
* Lin (crybabylin)
* woah (resourcepacks)
* Firefly / Alyssa (alychemist)
* daneirrix (daneirrix)

* ...and those from the early days who have been forgotten, and those would wish to remain unnamed.

## Outside Contributors
* paperbox (paperbox4147)
* Moe (mo.1.mu.u)


# Contributing to the Resource Pack via GitHub: A How-to For RP Artists
## First, some definitions
* Git: a version control system (VCS). Think of it as a way to take snapshots of the textures, properties, source models, and other files you're working on at any given moment with the ability to go back to those things later or to look at someone else's stuff without losing what you're doing.
* GitHub: a website with lots of neat technical features owned by Microsoft that lets you collaborate with others over the Internet using Git. Contrary to popular belief, you don't need to be working on programming or code to create a project here.
* Repository (repo): A project that Git tracks for you. Repositories have multiple features and allow multiple people to work on the same files at the same time.
* Branch: A contiguous history of files. Branches track changes you make to files and allow you to go back to previous versions of your work. You can also switch to someone else's work by checking out their branch.
* Main/Master Branch: The de-facto version of the repo and the first one created when you create a new repo. This is where your files and other people's files can be combined to add new textures to the resource pack.
* Origin: The remote version of the repo that everyone interacts with.
* Local: Your computer's version of the repo that only you interact with.
## Getting started
* Download and install [Git](<https://git-scm.com/downloads>). Don't bother getting one of the GUI versions, just get the standalone installer for your OS. Once you have it downloaded, allow all of the default options because you don't need to worry about what the default editor is or anything like that. You won't ever interact with plain Git unless you become a programmer.
* Create a [GitHub Account](<https://github.com/>). This requires an email and password. Save your credentials somewhere safe! You will need them later in this guide and throughout your time contributing to the project.
* Download and install [GitHub Desktop](<https://desktop.github.com/>). Use the default settings for this as well. Assuming this is your first time installing, it should ask you for your GitHub credentials. This will do some magic between GitHub and your web browser that tells GitHub you are who you say you are.
* If you haven't already, in GitHub Desktop, link your GitHub account. On the top left corner, click "File -> Options...". This will open a box. Sign into your account by clicking on the blue "Sign in" button. This should do the magic I mentioned in the previous step and you may need to interact with your browser.
* Send your GitHub account link to USB, Combustible, NickNackGus, or one of the RP Leads. It'll look something like this: <https://github.com/Spy21DD>. They'll get you set up with permissions to use the repo.
You're now set up with the necessary tools!
## Your First Contribution
* First, you need to make a clone of the repo on your local machine. In Git speak, creating a copy is called cloning. In your web browser, navigate to the RP repository on [GitHub](<https://github.com/TeamMonumenta/monumenta-resourcepack>). On the main page, there will be a green "Code" button. Click on it and click on the "Open with GitHub Desktop" button. This should make your browser forward the information to GitHub Desktop. If it doesn't, open GitHub Desktop. On the top left corner, click "File -> Clone repository...". This will open a box. Click "URL". Paste the URL you saw after clicking the "Code" button on GitHub.
* Now that you have the repository set up, it's time to make your first branch! In GitHub Desktop, click on the button that says "Current branch" and make sure you're on "main". Now, click "Branch -> New branch..." and give your branch a fitting name. For example, I usually include my name followed by what I'm planning on adding/changing with the branch, e.g. spy-create-more-lag. Now that you're on your new branch, do your work on the RP as you would do normally.
* Once you finish your work, "commit" your changes by adding a description to your commit at the bottom left of GitHub Desktop. A "commit" is one version of your branch and if you ever need to, you can go back to a previous commit to undo changes. You can make as many commits as you need while you work on your branch.
* You now have a branch full of cool changes! It's time to let everyone else see your changes on GitHub. If you've just made a commit, there will be a blue button in the middle of your screen labeled "Create Pull Request". This will open your browser. On GitHub, make sure your description from the commit you last made is still there and click on the green "Create Pull Request" button. What you've done is ask for your branch to be "merged" into the main branch. This will end the history of your branch and puts all of your new files into the main branch. In GitHub Desktop, make sure to switch back to the main branch by clicking on the "Current branch" button. Always make new branches based on main so that you don't run into conflicts with other people's files down the line.

## Additional topics
* Want to check out someone else's work on your own computer? Click on the "Current branch" button to see a list of branches published on GitHub.
* Need to undo some work you just committed? Under the "Current repository" button, click on "History" and find your commit. Right click on it and select "Revert changes in commit".
